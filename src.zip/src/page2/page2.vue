<template>
    <div>
        <iv-visualisation :title="pageName" :vue_config="vue_config" :page_number="1" :hotspotColumnSize="hotspotWidth">
            <div style="padding-left:30px; padding-top:10vh; width:60vw;">
                <div id="graph"></div>               
            </div>

            <template #hotspots>
                
                <iv-fixed-hotspot :noWastedSpace="true" position="topleft" style=" z-index: 2;">
                    
                    <div v-if="firstClick==true" style="font-size: 16px;">
                        <p>
                        This is a <a :href="url" target="_blank">{{compName}}</a>.
                        {{explanation}}

                        </p>
                    </div>
                    <div v-if="firstClick==false" style="font-size: 16px;">
                        <p>
                        <b>This page is all about ImpVis components! </b> <br> Descriptions of the components will appear here when you click on them! Click on the 'Components' toggle hotspot on the right to get started.
                        </p>
                    </div>


                </iv-fixed-hotspot>

                <!-- <iv-fixed-hotspot :noWastedSpace="true" position="topright" style=" z-index: 2;"> -->
                <iv-toggle-hotspot title="Components" :glass=true position="right">
                    
                    <iv-button @click="drawClick">Draw!</iv-button>
                    
                    <div v-show="firstClick==true">

                        <div class="row">
                            <div style="width:50%; float:left; padding-top:13px;"> Y-intercept </div>
                            <div style="width:50%; float:right;" > <iv-increment-button @change="interceptChange" :initialValue="0" :maximum="3"></iv-increment-button> </div>
                        </div>
                        
                        <iv-slider @sliderChanged="gradientChange" name="Gradient" :min="0" :max="3" :init_val="1" :step="0.1" :playButton="true"></iv-slider>
                        
                
                        <div class="row" style="padding-top:17px;">
                            <div class="column left" style="padding-top:0px;"> Show grid </div>
                            <div class="column right" > <iv-tickbox :disabled="disable" :value="true" @check="axisShow" :initialState="true" /> </div>
                        </div>
                        <br>

                        <div class="row">
                            <div class="column left"> Markers off/on </div>
                            <div class="column right" > <iv-toggle-basic :value="true" @input="markerChange" /> </div>
                        </div>

                        <div class="row" style="padding-top:5px;">
                            <div style="width:35%; float:left; padding-top:5px;"> Line colour </div>
                            <div style="width:65%; float:right;" > <iv-toggle-advance id="toggle" :width="width1" :togglesDisabled="[disable,disable,disable]" :modes=modeNames @toggleswitched="colourChange" position="centre" /></div>
                        </div>

                        <!-- <iv-guidance-button @click="guidanceRequest"></iv-guidance-button> -->

                        <div class="row" style="padding-top:5px;padding-bottom:5px;">
                            <div style="width:70%; float:left; padding-top:5px;"> X axis label </div>
                            <div style="width:30%; float:right;" > <iv-dropdown-list :dropdownItems="dropdownList" @dropdownbuttonclicked="showDropdown" @dropdownelementclicked="changeXlabel" ></iv-dropdown-list></div>
                        </div>

                        <iv-symbol-button symbol="Help" @click="helpRequest" size="small"></iv-symbol-button> 

                        <div style="padding-top:6px">
                            <iv-reset-button @click="onReset">Reset</iv-reset-button>
                        </div>
                    </div>           
                </iv-toggle-hotspot>
            </template>
        </iv-visualisation>
    </div>
</template>
<script>
import vue_config from '../../vue.config.js';
import Plotly from 'plotly.js';
export default {
    name:"page2",
    data(){
        return {
            pageName:"Components",
            vue_config,
            drawPressed:false,
            intercept:0,
            gradient:1,
            updateGraph:false,
            axisChange:false,
            axis:true,
            duration1:250,
            tickValues:[],
            colour:"red",
            markers:"lines+markers",
            explanation:"",
            url:"https://wiki.impvis.co.uk/index.php?title=Fixed_Hotspot",
            compName:"fixed hotspot",
            firstClick:false,
            xlabel:"x",
            ylabel:"y",
            disable:true,
        }
    },
    props:{
        modeNames:{default:["Red","Blue","Green"]},
        disableList:{default:[false,false,false]},
        width1:{default:"45px"},
        hoverText:{default: "Need a hint?"},
        hoverShow:{default: "This is a secret message! Both the hover text and message is customisabe. Try hitting draw and playing around with the components in the fixed hotspot."},
        hotspotWidth:{default:"35vw"},
        dropdownList:{default:["X","Time","Speed"]},
    
    },

    methods:{
        drawClick(){
            this.firstClick=true;
            this.disable=false;
            this.drawPressed=true;
            this.compName="button";
            this.url="https://wiki.impvis.co.uk/index.php?title=Button";
            this.explanation="It can carry out any function you'd like it to."
        },
        interceptChange(e){
            this.intercept=e;
            this.duration1=250;
            this.updateGraph=true;
            this.compName="increment button";
            this.url="https://wiki.impvis.co.uk/index.php?title=Increment_button"
            this.explanation="It can start off at any value, and controls the input by letting the user increment/decrement by a fixed given amount. The minimum and maximum possible input can be specified, in this example being 0 and 3."
        },
        gradientChange(e){
            this.gradient=e;
            // this.duration1=0;
            this.updateGraph=true;
            this.compName="slider";
            this.url="https://wiki.impvis.co.uk/index.php?title=Slider"
            this.explanation="It's minimum, maximum, and step size can be specified. It comes with an optional play button, which animates through the range of values."
        },
        axisShow(e){
            this.axis=e;
            this.axisChange=true;
            this.compName="tickbox";
            this.url="https://wiki.impvis.co.uk/index.php?title=Tickbox"
            this.explanation=""
        },
        colourChange(e){
            switch (true) {//sets line color based on conditions
                case (e==0):
                    this.colour="red";
                    break
                case (e==1):
                    this.colour="blue";
                    break
                case (e==2):
                    this.colour="green";
                    break
            }
            this.compName="advanced toggle";
            this.url="https://wiki.impvis.co.uk/index.php?title=Advance_toggle"
            this.explanation="You can specify the number and names of tabs that the user can choose from."
            this.updateGraph=true;
        },
        helpRequest(){
            alert("This is a symbol button. It can carry out any function like a normal button would, for example, creating an alert like this! For the full range of symbols available, please visit https://wiki.impvis.co.uk/index.php?title=Symbol_Button .");
        },
        markerChange(e){
            if(e==true){
                this.markers="lines"
            }
            else{
                this.markers="lines+markers"
            }
            this.compName="basic toggle";
            this.url="https://wiki.impvis.co.uk/index.php?title=Basic_toggle"
            this.explanation=""
            this.updateGraph=true;

        },
        onReset(){
            this.compName="reset button";
            this.url="https://wiki.impvis.co.uk/index.php?title=Reset_button"
            this.explanation="It resets any sliders, basic/advanced toggles, increment buttons, tickboxes, and dropdown lists on the page to their intitial value."
        },
        showDropdown(){
            this.compName="dropdown list";
            this.url="https://wiki.impvis.co.uk/index.php?title=Dropdown_List"
            this.explanation=""
        },
        changeXlabel(e){
            switch (true) {
                case (e==0):
                    this.xlabel="x";
                    break
                case (e==1):
                    this.xlabel="Time";
                    break
                case (e==2):
                    this.xlabel="Speed";
                    break
            }
            this.labelChange=true;
        },



    },

    mounted(){
        let v=this;
        let tickValues=[0,1,2,3,4,5];

        const
        plt = {//layout of graph
            layout: {
                legend: {x: 0, y: 0, orientation: 'h'},
                autosize: true,
                xaxis: {
                    autorange: false,
                    title: v.xlabel,
                    titlefont: {
                        family: "Fira Sans",
                        size: 22,
                        color: '#7f7f7f'
                    },
                    range: [0,5],
                    tickvals: tickValues,
                    ticktext: tickValues,
                    tickfont: {
                    family: "Fira Sans",
                    size: 18,
                    color: 'black'
                    },
                },
                yaxis: {
                    autorange: false,
                    title: v.ylabel,
                    titlefont: {
                        family: "Fira Sans",
                        size: 22,
                        color: '#7f7f7f'
                    },
                    range: [0,5],
                    tickvals: tickValues,
                    ticktext: tickValues,
                    tickfont: {
                    family: "Fira Sans",
                    size: 18,
                    color: 'black'
                    },
                },
                hovermode: false,
            }
        };

    
        Plotly.newPlot('graph',[],plt.layout);

        function getData(){
            let trace1 = {
                x: [0, 1, 2, 3, 4],
                y: [v.gradient*0 +v.intercept, v.gradient*1+v.intercept, v.gradient*2+v.intercept, v.gradient*3+v.intercept, v.gradient*4+v.intercept] ,
                mode: v.markers,
                type: 'scatter',
                line: {
                    color:v.colour
                }
            };
            let data1 =[trace1];
            return data1;
        }


        function draw(){
            Plotly.newPlot('graph', getData(), plt.layout);
        }

        function updateGraph(){
            Plotly.animate('graph', {
                data: getData(), 
                layout: plt.layout,
            }, {
                transition: {
                    duration: v.duration1,
                    easing: 'cubic-in-out'
                },
                mode: 'next',
            });


        }

        function animate(){
            requestAnimationFrame(animate);

            if(v.drawPressed==true){
                draw();
                v.drawPressed=false;
            }

            if(v.updateGraph==true){
                updateGraph();
                v.updateGraph=false;                
            }

            if(v.axisChange==true){
                if (v.axis==true){
                    plt.layout.xaxis.tickvals=tickValues;
                    plt.layout.xaxis.ticktext=tickValues;
                    plt.layout.yaxis.tickvals=tickValues;
                    plt.layout.yaxis.ticktext=tickValues;
                }
                else{
                    plt.layout.xaxis.tickvals=[];
                    plt.layout.xaxis.ticktext=[];
                    plt.layout.yaxis.tickvals=[];
                    plt.layout.yaxis.ticktext=[];
                }
                

                updateGraph();
                v.axisChange=false;
            }

            if(v.labelChange==true){
                plt.layout.xaxis.title=v.xlabel;
                // plt.layout.yaxis.title=v.ylabel;

                updateGraph();
                v.labelChange=false;
            }
        }
        

        animate();

    }
}
</script>
<style>
.iv-welcome-message{
    display:flex;
    flex-direction: column;
    align-items: center;
    margin-top: 50px;
}
.column {
  float: left;
  margin-top: 10px;
}

.left {
  width:85%;
  padding-bottom:"10px";
}

.right {
  width: 15%;
  padding-bottom:"10px";
  float:right;
}


.row:after {
  content: "";
  display: table;
  clear: both;
}
</style>