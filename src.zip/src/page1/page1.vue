<template>
    <div>
        <iv-DraggableDiv idName="Control Panel 1">
            <p> This is <a href="https://wiki.impvis.co.uk/index.php?title=Draggable_Hotspot" target="_blank"> draggable hotspot</a>. Components and text can be placed inside it. Its initial position
            can be specified, although when clicked, it pops out and can be dragged around the page! Hit the yellow x button at the top right corner to 
            return the hotspot to its original position.</p>
        </iv-DraggableDiv>
        <iv-visualisation :title="pageName" :vue_config="vue_config" :page_number="1">
            <div class="iv-welcome-message">
                <b> This page is all about layouts <br> and ways to structure your visualisations!</b>
                
                <!-- <iv-drag-and-drop></iv-drag-and-drop> -->
     
                <!-- <iv-section-title>Test</iv-section-title> -->
                
                <!-- <iv-slider-block></iv-slider-block> -->
                <!-- SVG drag and drops -->
                <!-- <iv-tabs>
                    <iv-tab> test </iv-tab>
                </iv-tabs> -->
                
                <!-- <iv-play-button></iv-play-button> -->
                
            </div>

            <template #hotspots>
                <iv-pane position="left" format="push" :width=28>
                    <iv-sidebar-content :showPagination="true">
                        <iv-sidebar-section title="Panes" icon="question" theme="Lime" >
                            <p>
                                This is a <a href="https://wiki.impvis.co.uk/index.php?title=Pane" target="_blank"> pane</a>, which can be created on either the left or right hand side of the page.
                            </p>
                            <p>
                                You can specify subsections within the pane, alongside their colour and associated icon. In this example, there are 4 subsections.
                            </p>
                            <p>
                                A 'next' button is also provided at the end of the pane to access the next/previous pages of the visualisation, if there are any!
                            </p>
                        </iv-sidebar-section>

                        <iv-sidebar-section title="Equations" icon="calculator" >
                            <p>
                                The <a href="https://wiki.impvis.co.uk/index.php?title=Equation_box" target="_blank"> equation</a> component allows you to display maths in LaTeX. They can be styled in boxes, <iv-equation-box :stylise="true" equation="y=mx + c"/>,
                                or without, <iv-equation-box :stylise="false" equation="y=mx+c"/>. 
                            </p>
            
                        </iv-sidebar-section>

                        <iv-sidebar-section title="Hidden text" icon="search" theme="Purple" >
                            <p>
                                Below is a <a href="https://wiki.impvis.co.uk/index.php?title=Hover_Text" target="_blank"> hover text</a> component.
                                You can specify the text and secret message - hover over it to see what it reveals!
                                <br>
                                <iv-hover-text :hoverElement="hoverText" :defaultText="hoverShow" ></iv-hover-text>
                                <br>
                                Below is a <a href="https://wiki.impvis.co.uk/index.php?title=Dropdown_Textbox" target="_blank"> dropdown textbox</a> component.
                                Once clicked on, text is revealed.
                                <br>
                                <iv-dropdown-text-box :dropdownText="dropdownText"></iv-dropdown-text-box>
                            </p>
            
                        </iv-sidebar-section>

                        <iv-sidebar-section title="Loaders" icon="ellipsis-h" theme="Turqouise" >
                           
                            <p> Below is a <a href="https://wiki.impvis.co.uk/index.php?title=Loading_Bar" target="_blank"> loading bar</a>. You can use it to display the loading progress of a visualisation if it is anticipated to be long.</p>
                            <iv-loading-bar :loadingProgress=loadAmount></iv-loading-bar>
                            <p> The <a href="https://wiki.impvis.co.uk/index.php?title=Meter" target="_blank"> meter</a> component offers a simpler alternative to the loading bar.
                            <iv-meter :value=loadAmount :min=0 :max=100></iv-meter>
                            <p> Below is a <a href="https://wiki.impvis.co.uk/index.php?title=Loading_spinner" target="_blank"> loading spinner</a>. It can fit into smaller spaces compared to the loading bar.</p>
                            <iv-loading-spinner></iv-loading-spinner>
                        
                        </iv-sidebar-section>
                        
                    </iv-sidebar-content>
                </iv-pane>


                <iv-fixed-hotspot :noWastedSpace="true" position="topright" style=" z-index: 2;">
                    <p>
                    <i> This is a <a href="https://wiki.impvis.co.uk/index.php?title=Fixed_Hotspot" target="_blank"> fixed hotspot</a>. Its location can be specified on the page, and components and text can be placed inside it.</i>
                    </p>
                </iv-fixed-hotspot>

                <iv-toggle-hotspot title="Toggle hotspot" :glass=true position="bottom">
                    <div>
                        <p>
                            <i> This is a <a href="https://wiki.impvis.co.uk/index.php?title=Toggle_Hotspot" target="_blank"> toggle hotspot</a>. Its location can be specified on the page, and components and text can be placed inside it.</i>
                        </p>
                
                    </div>
                </iv-toggle-hotspot>


                <iv-toggle-hotspot :draggable=true position='right' title='Draggable Hotspot' idName="Control Panel 1">
                </iv-toggle-hotspot>
            </template>
        </iv-visualisation>
    </div>
</template>
<script>
import vue_config from '../../vue.config.js'
export default {
    name:"page1",
    data(){
        return {
            pageName:"Layouts",
            vue_config,
            loadAmount:25,
        }
    },
    props:{
        dropdownText:{default:"This is also hidden text"},
        hoverShow:{default:"This is a secret message!"},
        hoverText:{default:"Hover over me!"}
    },
    mounted(){
        function animate(){
            requestAnimationFrame(animate);
        }


        animate();

    }
}
</script>
<style>
.iv-welcome-message{
    display:flex;
    flex-direction: column;
    align-items: left;
    padding-left:10vw;
    margin-top: 50px;
}
</style>


